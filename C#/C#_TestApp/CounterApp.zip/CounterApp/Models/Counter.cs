#pragma warning disable CS8618
namespace CounterApp.Models;

public class Counter 
{
    public int Number {get;set;}
}